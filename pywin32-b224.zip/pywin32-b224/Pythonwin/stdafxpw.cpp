// stdafxpw.cpp : source file that includes just the standard includes
// Python for Windows version.
//	stdafxpw.pch will be the pre-compiled header
//	stdafxpw.obj will contain the pre-compiled type information

#include "stdafxpw.h"

