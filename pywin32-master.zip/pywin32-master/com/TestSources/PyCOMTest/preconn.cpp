// preconn.cpp : source file that includes just the standard includes
//  preconn.pch will be the pre-compiled header
//  preconn.obj will contain the pre-compiled type information

#include "preconn.h"

#include "atlimpl.cpp"
