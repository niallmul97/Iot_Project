These files are all demos of a Pythonwin "Application".

To run these demos, you should use the command line:

pythonwin /app filename.py

where filename.py is one of the demos in this directory.